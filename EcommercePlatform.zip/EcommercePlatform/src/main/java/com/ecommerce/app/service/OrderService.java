package com.ecommerce.app.service;

import com.ecommerce.app.entity.*;
import com.ecommerce.app.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {

    @Autowired
    private CartRepository cartRepo;

    @Autowired
    private OrderRepository orderRepo;

    @Autowired
    private UserRepository userRepo;

    //CREATE ORDER
    public Order createOrder(User user) {

        List<Cart> cartItems = cartRepo.findByUser_UserId(user.getUserId());

        if (cartItems.isEmpty()) {
            return null;
        }

        Order order = new Order();
        order.setUser(user);
        order.setStatus("PENDING");
        order.setOrderDate(LocalDate.now());

        List<OrderItem> items = new ArrayList<>();
        double total = 0;

        for (Cart cart : cartItems) {

            OrderItem item = new OrderItem();
            item.setOrder(order);
            item.setProduct(cart.getProduct());

            item.setQuantity(cart.getQuantity());
            item.setPrice(cart.getProduct().getPrice());

            item.setProductName(cart.getProduct().getName());
            item.setProductDescription(cart.getProduct().getDescription());
            item.setProductImageUrl(cart.getProduct().getImageUrl());

            total += item.getQuantity() * item.getPrice();
            items.add(item);
        }

        order.setItems(items);
        order.setTotalAmount(total);

        orderRepo.save(order);

        for (Cart cart : cartItems) {
            cartRepo.delete(cart);
        }

        return order;
    }

    // GET ORDER BY ID
    public Order getOrderDetails(Long orderId) {
        return orderRepo.findById(orderId).orElseThrow();
    }

    // GET ALL ORDERS(ADMIN)
    public List<Order> getAllOrders() {
        return orderRepo.findAll();
    }

    // GET ORDERS BY USER
    public List<Order> getOrdersByUser(Long userId) {
        return orderRepo.findByUser_UserId(userId);
    }

    // UPDATE STATUS
    public void updateOrderStatus(Long orderId, String status) {
        Order order = orderRepo.findById(orderId).orElseThrow();
        order.setStatus(status);
        orderRepo.save(order);
    }
 // get orders by User id
    public List<Order> getOrdersByUserId(Long userId) {
        return orderRepo.findByUser_UserId(userId);
    }

    // delete Order
    public void deleteOrder(Long orderId) {
        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        orderRepo.delete(order);
    }
}