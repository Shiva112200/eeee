package com.ecommerce.app.controller;

import com.ecommerce.app.config.JwtFilter;
import com.ecommerce.app.entity.Order;
import com.ecommerce.app.entity.User;
import com.ecommerce.app.service.OrderService;
import com.ecommerce.app.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
@CrossOrigin(origins = "*")

public class OrderController {

    @Autowired
    private OrderService service;

    @Autowired
    private UserService userService;

    //create order
    @PostMapping("/{userId}")
    public Order createOrder(@PathVariable Long userId) {
        User user = userService.getUserProfile(userId);
        return service.createOrder(user);
    }

    //get order by id
    @GetMapping("/{orderId}")
    public Order getOrder(@PathVariable Long orderId) {
        return service.getOrderDetails(orderId);
    }

    //get all orders
    @GetMapping
    public List<Order> getAll() {
        if (!JwtFilter.currentRole.equals("ADMIN")) {
            throw new RuntimeException("Only ADMIN can get all orders");
        }
        return service.getAllOrders();
    }

    //get orders by user id
    @GetMapping("/user/{userId}")
    public List<Order> getOrdersByUser(@PathVariable Long userId) {
        return service.getOrdersByUserId(userId);
    }

    // delete order
    @DeleteMapping("/{orderId}")
    public String deleteOrder(@PathVariable Long orderId) {

        if (!(JwtFilter.currentRole.equals("ADMIN") || JwtFilter.currentRole.equals("CUSTOMER"))) {
            throw new RuntimeException("Unauthorized access");
        }

        service.deleteOrder(orderId);
        return "Order Deleted Successfully";
    }
}