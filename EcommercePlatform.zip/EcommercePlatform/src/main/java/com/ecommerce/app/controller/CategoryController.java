package com.ecommerce.app.controller;

import com.ecommerce.app.config.JwtFilter;
import com.ecommerce.app.entity.Category;
import com.ecommerce.app.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/categories")
@CrossOrigin("*")
public class CategoryController {

	@Autowired
	private CategoryService service;

	// Add category
	@PostMapping
	public Category addCategory(@RequestBody Category category) {

		if (!JwtFilter.currentRole.equals("ADMIN")) {
			throw new RuntimeException("Only ADMIN can add product");
		}

		return service.addCategory(category);
	}

	// Get all categories
	@GetMapping
	public List<Category> getAll() {

		if (!JwtFilter.currentRole.equals("ADMIN")) {
			throw new RuntimeException("Only ADMIN can add product");
		}

		return service.getAllCategories();
	}
}
