package com.ecommerce.app.service;

import com.ecommerce.app.entity.User;
import com.ecommerce.app.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

	@Autowired
	private UserRepository repo;

	// Register User
	public User registerUser(User user) {
	    Optional<User> userOpt = repo.findByUsername(user.getUsername());
	 
	    // If username already exists, do not register
	    if (userOpt.isPresent()) {
	        throw new RuntimeException("Username already exits");
	        // alternatively: return null;
	    }
	 
	    // Set default role
	    user.setRole("CUSTOMER");
	 
	    return repo.save(user);
	}

	// Login
	public User loginUser(String username, String password) {
		Optional<User> userOpt = repo.findByUsername(username);

		if (userOpt.isPresent()) {
			User user = userOpt.get();

			if (user.getPassword().equals(password)) {
				return user;
			}
		}

		throw new RuntimeException("Invalid username or password");
	}

	// Get Profile
	public User getUserProfile(Long userId) {
		return repo.findById(userId).orElseThrow();
	}

	// Update Profile
	public User updateUser(Long userId, User updatedUser) {
	    User user = repo.findById(userId).orElseThrow();

	    user.setUsername(updatedUser.getUsername());
	    user.setEmail(updatedUser.getEmail());

	    // ✅ NEW FIELDS
	    user.setAddress(updatedUser.getAddress());
	    user.setCity(updatedUser.getCity());
	    user.setState(updatedUser.getState());
	    user.setPincode(updatedUser.getPincode());
	    user.setPhoneNumber(updatedUser.getPhoneNumber());

	    return repo.save(user);
	}

	public List<User> getAllUsers() {
		return repo.findAll();
	}
	
	public void deleteUser(Long id) {
	    repo.deleteById(id);
	}
}