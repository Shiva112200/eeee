package com.ecommerce.app.controller;

import com.ecommerce.app.config.JwtFilter;
import com.ecommerce.app.config.JwtUtil;
import com.ecommerce.app.entity.User;
import com.ecommerce.app.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
@CrossOrigin("*")
public class UserController {

	@Autowired
	private UserService service;

	@Autowired
	private JwtUtil jwtUtil;

	// Register
	@PostMapping("/register")
	public User registerUser(@RequestBody User user) {
		return service.registerUser(user);
	}

	@PostMapping("/login")
	public String loginUser(@RequestBody User user) {

		User dbUser = service.loginUser(user.getUsername(), user.getPassword());
		String token = jwtUtil.generateToken(dbUser.getUserId().toString(), dbUser.getRole());

		return token;
	}

	// Profile
	@GetMapping("/{id}")
	public User getProfile(@PathVariable Long id) {
		return service.getUserProfile(id);
	}

	// Update
	@PutMapping("/{id}")
	public User updateUser(@PathVariable Long id, @RequestBody User user) {
		return service.updateUser(id, user);
	}

	// All users (admin use)
	@GetMapping
	public List<User> getAllUsers() {

		if (!JwtFilter.currentRole.equals("ADMIN")) {
			throw new RuntimeException("Only ADMIN can add product");
		}

		return service.getAllUsers();
	}

	// ✅ DELETE USER (ADMIN ONLY)
	@DeleteMapping("/{id}")
	public String deleteUser(@PathVariable Long id) {

		// ✅ Only admin can delete
		if (!JwtFilter.currentRole.equals("ADMIN")) {
			throw new RuntimeException("Only ADMIN can delete users");
		}

		service.deleteUser(id);
		return "User deleted successfully ✅";
	}
}